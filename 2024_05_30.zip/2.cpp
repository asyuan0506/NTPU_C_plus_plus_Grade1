#include <iostream>
#include <string>
#include <stack>
#include "BST.h"

int main() {
    std::string numbers;
    getline(std::cin, numbers);

    std::stack<int> nums;
    for (int i = numbers.length() - 1; i >= 0; i--) {
        int num = 0;
        int times = 1;
        while (i >= 0 && numbers[i] != ' ') {
            num += (numbers[i]-48) * times;
            times *= 10;
            i--;
            nums.push(num);
        }
    }
    TreeNode node(nums.top());
    nums.pop();
    Binary_Search_Tree my_tree(&node, nums);

    int find_num;
    std::cout << "Find the number you want...\n";
    while (std::cin >> find_num) {
        if (find_num == -1)
            break;
        if (!my_tree.search_node(find_num))
            std::cout << "The value is not in this binary search tree.\n";
    }

    system("pause");
}
