#include <iostream>
#include <string>

using namespace std;

int main() {
    string in;
    while(cin >> in) {
        if (in == "0")
            break;
        for (int i = in.length(); i >= 0; i--)
            cout << in[i];
        cout << endl;
    }

}
