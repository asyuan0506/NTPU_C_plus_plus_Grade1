#ifndef BST_H_INCLUDED
#define BST_H_INCLUDED
#include <stack>

struct TreeNode {
	int val;
	TreeNode *left;
	TreeNode *right;
	TreeNode(int x) : val(x), left(nullptr), right(nullptr) {};
};

class Binary_Search_Tree {
private:
    TreeNode* tree_node;
	std::stack<int> my_stack;
public:
     Binary_Search_Tree(TreeNode*, std::stack<int>);
     bool search_node(int);
	 TreeNode* tree_establish(TreeNode*);
	 void delete_tree(TreeNode*);
	 ~Binary_Search_Tree();
};


#endif
