#include "BST.h"
#include <iostream>

Binary_Search_Tree::Binary_Search_Tree(TreeNode* node, std::stack<int> st) {
    tree_node = new TreeNode(node->val);
    my_stack = st;
    tree_establish(tree_node);
}

bool Binary_Search_Tree::search_node(int num) {
    TreeNode* cur_node = tree_node;
    while (cur_node != NULL) {
        if (num == cur_node->val) {
            if (cur_node->left == NULL)
                std::cout << "left:null";
            else
                std::cout << "left:" << cur_node->left->val;
            if (cur_node->right == NULL)
                std::cout << "\tright:null\n";
            else
                std::cout << "\tright:" << cur_node->right->val << std::endl;
            return true;
        }
        else if (num < cur_node->val)
            cur_node = cur_node->left;
        else if (num > cur_node->val) 
            cur_node = cur_node->right;
    }
    return false;
}

TreeNode* Binary_Search_Tree::tree_establish(TreeNode* Cur_node) {
    if (my_stack.empty())
        return Cur_node;
    if (my_stack.top() < Cur_node->val) {
        Cur_node->left = new TreeNode(my_stack.top());
        my_stack.pop();
        tree_establish(Cur_node->left);
    }
    if (Cur_node->left == NULL)
        return Cur_node;
    if (my_stack.top() > Cur_node->val) {
        Cur_node->right = new TreeNode(my_stack.top());
        my_stack.pop();
        tree_establish(Cur_node->right);
    }
    return Cur_node;
}

void Binary_Search_Tree::delete_tree(TreeNode* node) {
    if (node->left != NULL)
        delete_tree(node->left);
    if (node->right != NULL)
        delete_tree(node->right);
    delete node;
}

Binary_Search_Tree::~Binary_Search_Tree() {
    delete_tree(tree_node);
}
